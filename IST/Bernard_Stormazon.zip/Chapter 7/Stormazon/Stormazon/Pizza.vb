﻿Public Class frmPizza
    Public dblCheese = 20.99
    Public dblPepperoni = 22.99
    Public dblTaco = 24.99
    Public dblCheeseBurger = 29.99
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnAddPizza.Click
        addPizza()
    End Sub
End Class