﻿Public Class frmSides
    Public dblBread As Double = 4.99
    Public dblPasta As Double = 9.99
    Public dblWings As Double = 2.99
    Public dblSticks As Double = 0.99
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnAddSides.Click
        addSides()
    End Sub
End Class