﻿Public Class frmTitle

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()
        ' Add any initialization after the InitializeComponent() call.

    End Sub
    Public page1 As Boolean = True ' determines whether the "Next" button has been pressed


    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles pbOne.Click
        pbMain.Visible = True 'Displays the main picture viewer
        If page1 = True Then
            lblLabel1.Text = "You Selected:"
            lblSelection.Visible = True
            lblSelection.Text = "Emporer Penguin" 'Describes the animal in the picture on the first page
            pbMain.Image = My.Resources.ep 'Displays the Emporer Penguin on the main picture viewer
        Else
            lblLabel1.Text = "You Selected:"
            lblSelection.Visible = True
            lblSelection.Text = "Polar Bear" 'Describes the animal in the picture on the second page    
            pbMain.Image = My.Resources.pb 'Displays the Polar Bear on the main picture viewer
        End If

    End Sub
    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles pbTwo.Click


        pbMain.Visible = True 'Displays the main picture viewer

        If page1 = True Then
            lblLabel1.Text = "You Selected:"
            lblSelection.Visible = True
            lblSelection.Text = "English Bulldog"  'Describes the animal in the picture on the first page
            pbMain.Image = My.Resources.eb  'Displays the English Bulldog on the main picture viewer
        Else
            lblLabel1.Text = "You Selected:"
            lblSelection.Visible = True
            lblSelection.Text = "White Tiger"  'Describes the animal in the picture on the second page 
            pbMain.Image = My.Resources.wt   'Displays the White Tiger on the main picture viewer
        End If
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles pbThree.Click
        pbMain.Visible = True  'Displays the main picture viewer

        If page1 = True Then
            lblLabel1.Text = "You Selected:"
            lblSelection.Visible = True
            lblSelection.Text = "Giant Panda"  'Describes the animal in the picture on the first page
            pbMain.Image = My.Resources.gp   'Displays the Giant Panda on the main picture viewer
        Else

            lblLabel1.Text = "You Selected:"
            lblSelection.Visible = True
            lblSelection.Text = "Lion"  'Describes the animal in the picture on the second page 
            pbMain.Image = My.Resources.ll   'Displays the White Tiger on the main picture viewer
        End If
    End Sub
    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        page1 = False 'now that the 'Next' button has been pressed we are on page 2
        btnNext.Enabled = False 'this will disable the next button as we are on the last page
        'Reset the text of the labels and remove image from main animal viewer as no animal is selected
        lblLabel1.Text = "Click a picture to make a selection"
        lblSelection.Visible = False
        pbMain.Visible = False
        btnBack.Enabled = True
        'Reset the animal choices
        pbOne.Image = My.Resources.pb
        pbThree.Image = My.Resources.ll
        pbTwo.Image = My.Resources.wt

    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        'Go back to Page 1 
        page1 = True
        btnBack.Enabled = False 'disabled as we are on the first page
        btnNext.Enabled = True 'enable the "Next" button
        'Reset the labels and images and prompt for an animal selection
        lblLabel1.Text = "Click a picture to make a selection"
        lblSelection.Visible = False
        pbMain.Visible = False
        pbOne.Image = My.Resources.ep
        pbThree.Image = My.Resources.gp
        pbTwo.Image = My.Resources.eb

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'Exit the application
        Application.Exit()
    End Sub
End Class
