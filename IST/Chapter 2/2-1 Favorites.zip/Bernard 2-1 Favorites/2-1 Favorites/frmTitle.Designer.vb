﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTitle
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTitle))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pbThree = New System.Windows.Forms.PictureBox()
        Me.pbTwo = New System.Windows.Forms.PictureBox()
        Me.pbMain = New System.Windows.Forms.PictureBox()
        Me.lblLabel1 = New System.Windows.Forms.Label()
        Me.lblSelection = New System.Windows.Forms.Label()
        Me.pbOne = New System.Windows.Forms.PictureBox()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        CType(Me.pbThree, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbTwo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbMain, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbOne, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Roboto", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label1.Location = New System.Drawing.Point(373, 109)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(235, 63)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ANIMALS"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pbThree
        '
        Me.pbThree.Image = CType(resources.GetObject("pbThree.Image"), System.Drawing.Image)
        Me.pbThree.Location = New System.Drawing.Point(325, 287)
        Me.pbThree.Name = "pbThree"
        Me.pbThree.Size = New System.Drawing.Size(126, 120)
        Me.pbThree.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbThree.TabIndex = 2
        Me.pbThree.TabStop = False
        '
        'pbTwo
        '
        Me.pbTwo.Image = CType(resources.GetObject("pbTwo.Image"), System.Drawing.Image)
        Me.pbTwo.Location = New System.Drawing.Point(169, 287)
        Me.pbTwo.Name = "pbTwo"
        Me.pbTwo.Size = New System.Drawing.Size(126, 120)
        Me.pbTwo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbTwo.TabIndex = 3
        Me.pbTwo.TabStop = False
        '
        'pbMain
        '
        Me.pbMain.Location = New System.Drawing.Point(585, 232)
        Me.pbMain.Name = "pbMain"
        Me.pbMain.Size = New System.Drawing.Size(266, 175)
        Me.pbMain.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbMain.TabIndex = 4
        Me.pbMain.TabStop = False
        '
        'lblLabel1
        '
        Me.lblLabel1.AutoSize = True
        Me.lblLabel1.BackColor = System.Drawing.Color.Transparent
        Me.lblLabel1.Font = New System.Drawing.Font("Roboto", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLabel1.Location = New System.Drawing.Point(16, 485)
        Me.lblLabel1.Name = "lblLabel1"
        Me.lblLabel1.Size = New System.Drawing.Size(205, 18)
        Me.lblLabel1.TabIndex = 5
        Me.lblLabel1.Text = "Click a picture to make a selection"
        '
        'lblSelection
        '
        Me.lblSelection.AutoSize = True
        Me.lblSelection.BackColor = System.Drawing.Color.Transparent
        Me.lblSelection.Font = New System.Drawing.Font("Roboto", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSelection.Location = New System.Drawing.Point(166, 485)
        Me.lblSelection.Name = "lblSelection"
        Me.lblSelection.Size = New System.Drawing.Size(46, 18)
        Me.lblSelection.TabIndex = 6
        Me.lblSelection.Text = "Label3"
        Me.lblSelection.Visible = False
        '
        'pbOne
        '
        Me.pbOne.Image = CType(resources.GetObject("pbOne.Image"), System.Drawing.Image)
        Me.pbOne.Location = New System.Drawing.Point(12, 287)
        Me.pbOne.Name = "pbOne"
        Me.pbOne.Size = New System.Drawing.Size(126, 120)
        Me.pbOne.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbOne.TabIndex = 1
        Me.pbOne.TabStop = False
        '
        'btnBack
        '
        Me.btnBack.Enabled = False
        Me.btnBack.Location = New System.Drawing.Point(12, 560)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(87, 31)
        Me.btnBack.TabIndex = 7
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(415, 560)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(87, 31)
        Me.btnNext.TabIndex = 8
        Me.btnNext.Text = "Next"
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(944, 560)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(87, 31)
        Me.btnExit.TabIndex = 9
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmTitle
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global._2_1_Favorites.My.Resources.Resources.background
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.ClientSize = New System.Drawing.Size(1043, 603)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.lblSelection)
        Me.Controls.Add(Me.lblLabel1)
        Me.Controls.Add(Me.pbMain)
        Me.Controls.Add(Me.pbTwo)
        Me.Controls.Add(Me.pbThree)
        Me.Controls.Add(Me.pbOne)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Roboto", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmTitle"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "My Favorite Animals"
        CType(Me.pbThree, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbTwo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbMain, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbOne, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents pbThree As System.Windows.Forms.PictureBox
    Friend WithEvents pbTwo As System.Windows.Forms.PictureBox
    Friend WithEvents pbMain As System.Windows.Forms.PictureBox
    Friend WithEvents lblLabel1 As System.Windows.Forms.Label
    Friend WithEvents lblSelection As System.Windows.Forms.Label
    Friend WithEvents pbOne As System.Windows.Forms.PictureBox
    Friend WithEvents btnBack As System.Windows.Forms.Button
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
End Class
